<?php
	header("location:delegate_login.php?mes=");
?>
