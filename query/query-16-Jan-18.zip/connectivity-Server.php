<?php
	mysql_connect("localhost","mart_atrtcm","Pata##1951");
	mysql_select_db("mart_a2018_UAE");
?>